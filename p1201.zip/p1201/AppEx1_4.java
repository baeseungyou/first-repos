package p1201;

public class AppEx1_4 {
	public void eArray(int[] dt) {
		
		for(int i=0; i<dt.length-1; i++)
		{
			for(int j=i+1; j<dt.length;j++)
			{
				int temp;
				if(dt[i] > dt[j])
				{
					temp = dt[i];
					dt[i] = dt[j];
					dt[j] = temp;
					
				}
			}
		}
	}
	
				
	public static void main(String[] args) {
		AppEx1_4   k = new AppEx1_4();
		int[] data ;
		
		data = new int[]{10, 40, 50, 90, 100, 45, 76, 15, 3, 55 };
		
		System.out.print("�⺻ ������ : ") ;
		for(int i=0; i<data.length; i++)
			System.out.print(data[i] + " ");
		System.out.println();
		
		System.out.print("for each ���� ������ : ") ;
		for(int n:data)
			System.out.print(n + " ");
		System.out.println();
		
		k.eArray(data);
		
		System.out.print("�������� ������ : ") ;
		for(int n:data)
			System.out.print(n + " ");
		System.out.println();
	}
}
		
		
		

