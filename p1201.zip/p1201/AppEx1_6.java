package p1201;

class AppExBase{
	int[] data ;
	
	public void basePrint() {
		System.out.print("�⺻ ������ : ") ;
		for(int i=0; i<data.length; i++)
			System.out.print(data[i] + " ");
		System.out.println();
		
}

public class AppEx1_6 extends AppExBase{
	
	public AppEx1_6() {
	data = new int[]{10, 40, 50, 90, 100, 45, 76, 15, 3, 55 };
	}
	
	
	public void forEachPrint(String msg) {
		System.out.print(msg) ;
		for(int n:data)
			System.out.print(n + " ");
		System.out.println();
	}
	
	public void eArray() {
	for(int i=0; i<data.length-1; i++)
	{
		for(int j=i+1; j<data.length;j++)
		{
			int temp;
			if(data[i] > data[j])
			{
				temp = data[i];
				data[i] = data[j];
				data[j] = temp;
				
			}
		}
	}
}
	
public static void main(String[] args) {
	AppEx1_6   k = new AppEx1_6();
	
	k.basePrint();
	k.forEachPrint("for each ���� ������ : ");
	
	k.eArray();
	
	k.forEachPrint("�������� ������ : ");
}


	
	


